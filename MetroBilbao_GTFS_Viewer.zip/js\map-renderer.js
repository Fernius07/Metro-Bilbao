import CONFIG from './config.js';

class MapRenderer {
    constructor(containerId) {
        this.map = L.map(containerId, {
            center: CONFIG.MAP_CENTER,
            zoom: CONFIG.MAP_ZOOM,
            zoomControl: false,
            attributionControl: false
        });

        // Layers
        this.layers = {
            base: {
                standard: L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
                    attribution: '&copy; OpenStreetMap &copy; CARTO'
                }),
                satellite: L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
                    attribution: '&copy; Esri'
                })
            },
            shapes: L.layerGroup().addTo(this.map),
            stops: L.layerGroup().addTo(this.map),
            trains: L.layerGroup().addTo(this.map)
        };

        this.layers.base.standard.addTo(this.map);
        L.control.zoom({ position: 'bottomright' }).addTo(this.map);

        this.trainMarkers = new Map(); // trip_id -> L.marker
    }

    setTheme(theme) {
        if (theme === 'dark') {
            this.layers.base.standard.setUrl('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png');
        } else {
            this.layers.base.standard.setUrl('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png');
        }
    }

    toggleLayer(type) {
        if (type === 'satellite') {
            this.map.removeLayer(this.layers.base.standard);
            this.map.addLayer(this.layers.base.satellite);
        } else {
            this.map.removeLayer(this.layers.base.satellite);
            this.map.addLayer(this.layers.base.standard);
        }
    }

    renderStaticData(processedData) {
        // 1. Draw Shapes
        // We only draw one shape per unique geometry to avoid clutter, 
        // but we need to color it.
        // Strategy: Draw all unique shapes. Color by the most frequent route using it.

        const drawnShapes = new Set();

        processedData.routesById.forEach(route => {
            // Find trips for this route to get shape_id
            // This reverse lookup is inefficient, better to have route -> shape mapping.
            // For now, let's iterate trips.
        });

        // Simplified: Iterate shapes and find a route that uses it.
        processedData.shapesById.forEach(shape => {
            // Find a trip that uses this shape
            const trips = processedData.tripsByShapeId.get(shape.id);
            if (!trips || trips.length === 0) return;

            const routeId = trips[0].route_id; // Pick first route
            const route = processedData.routesById.get(routeId);

            const latlngs = shape.points.map(p => [p.lat, p.lon]);

            L.polyline(latlngs, {
                color: route.color,
                weight: 3,
                opacity: 0.7,
                smoothFactor: 1
            }).addTo(this.layers.shapes);
        });

        // 2. Draw Stops
        processedData.stopsById.forEach(stop => {
            L.circleMarker([stop.lat, stop.lon], {
                radius: 4,
                fillColor: '#fff',
                color: '#666',
                weight: 1,
                opacity: 1,
                fillOpacity: 1
            }).bindTooltip(stop.name).addTo(this.layers.stops);
        });
    }

    updateTrains(trains) {
        const activeIds = new Set(trains.map(t => t.trip_id));

        // Remove old trains
        for (const [id, marker] of this.trainMarkers) {
            if (!activeIds.has(id)) {
                this.layers.trains.removeLayer(marker);
                this.trainMarkers.delete(id);
            }
        }

        // Update/Add trains
        trains.forEach(train => {
            if (this.trainMarkers.has(train.trip_id)) {
                // Move
                const marker = this.trainMarkers.get(train.trip_id);
                marker.setLatLng([train.lat, train.lon]);
                marker.setTooltipContent(`${train.next_stop_name || '...'}`);
            } else {
                // Create
                // We need route color
                // Pass route color in train object or look it up?
                // Let's assume generic color if not passed, but we should pass it.
                // For now, simple circle.

                const marker = L.circleMarker([train.lat, train.lon], {
                    radius: 6,
                    fillColor: CONFIG.COLORS.accent, // Should be route color
                    color: '#fff',
                    weight: 2,
                    fillOpacity: 1
                }).bindTooltip(`${train.next_stop_name || '...'}`);

                marker.addTo(this.layers.trains);
                this.trainMarkers.set(train.trip_id, marker);
            }
        });
    }
}

export default MapRenderer;
